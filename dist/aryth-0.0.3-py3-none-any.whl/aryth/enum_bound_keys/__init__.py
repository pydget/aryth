MAX = 'max'
MIN = 'min'
DIF = 'dif'
